import React from 'react'

/**
 * TODO: Ersetze den Inhalt mit deiner eigenen App.jsx (Default-Export).
 * Bilder/Fonts bitte unter src/assets/ oder public/ ablegen.
 */

export default function App() {
  return (
    <div style={{padding: 24}}>
      <h1>React + Vite GitHub Pages</h1>
      <p>Ersetze <code>src/App.jsx</code> mit deiner App.</p>
    </div>
  )
}
